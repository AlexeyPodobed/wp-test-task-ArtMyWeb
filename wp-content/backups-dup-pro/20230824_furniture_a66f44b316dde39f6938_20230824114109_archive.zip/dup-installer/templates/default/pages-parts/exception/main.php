<?php
/**
 *
 * @package templates/default
 *
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="ajaxerr-data">
    <b style="color:#B80000;">INSTALL ERROR!</b>
    <p>
        Message: <b><?php echo DUPX_U::esc_html($exception->getMessage()); ?></b><br>
        Please see the <?php DUPX_View_Funcs::installerLogLink(); ?> file for more details.
        <?php
        if ($exception instanceof DupxException) {
            if ($exception->haveFaqLink()) {
                ?>
                <br>
                See FAQ: <a href="<?php echo $exception->getFaqLinkUrl(); ?>" ><?php echo $exception->getFaqLinkLabel(); ?></a>
                <?php
            }
            if (strlen($longMsg = $exception->getLongMsg())) {
                echo '<br><br>'.$longMsg;
            }
        }
        ?>
    </p>
    <hr>
    Trace:
    <pre class="exception-trace"><?php
        echo $exception->getTraceAsString();
        ?></pre>
</div>
<div style="text-align:center; margin:10px auto 0px auto">
    <i style='font-size:11px'>See online help for more details at <a href='https://snapcreek.com/ticket' target='_blank'>snapcreek.com</a></i>
</div>