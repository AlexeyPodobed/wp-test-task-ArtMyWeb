<?php
/**
 *
 * @package templates/default
 *
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;

?>
<div id="validate-no-result" >
    <p>Not validated yet</p>
</div>